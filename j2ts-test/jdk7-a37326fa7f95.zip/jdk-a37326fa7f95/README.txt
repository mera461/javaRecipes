
This workspace contains an early access implementation of the OpenJDK
Modules project - the reference implementation of JSR 277 and JSR 294.

For more information see http://openjdk.java.net/projects/modules/
